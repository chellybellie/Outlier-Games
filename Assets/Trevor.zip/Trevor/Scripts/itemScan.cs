﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class itemScan : MonoBehaviour {

    public string itemName;
    public string scanType;
    public int itemID;
 

	void Start () {
        scanType = "item";
	}
	
	
	void Update () {
		
	}
}
