﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mouseMoveTest : MonoBehaviour {

    GameObject cam;
    public Vector3 lastpos;
    public Vector3 curpos;
	void Start () {
        cam = this.gameObject;
        lastpos = Vector3.zero;
	}
	
	
	void Update () {
        

	}
}
